<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>xer0.ticker</title>
  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <div id="bar" class = "ticker-container">
	<div class = "ticker-text">
    <font size="150"><img src="blogo.png"></img><?php include("ticker.txt"); ?></font>
	</div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
